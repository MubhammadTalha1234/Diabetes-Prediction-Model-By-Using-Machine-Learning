


from flask import Flask, render_template, request, redirectpython app.py
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn import svm
import mysql.connector

app = Flask(__name__)

# Load the trained model
classifier = svm.SVC(kernel='linear')

# Load the scaler
scaler = StandardScaler()


# Load the database connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="diabetes_db"
)


# Load the diabetes dataset
diabetes_dataset = pd.read_csv('diabetes.csv')

# Separate features and target variable
X = diabetes_dataset.drop(columns='Outcome', axis=1)
Y = diabetes_dataset['Outcome']

# Standardize the data
scaler.fit(X)
X = scaler.transform(X)

# Train the model
classifier.fit(X, Y)

@app.route('/')
def home():
    return render_template('index.html')
# ...

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        input_data = [
            int(request.form['pregnancies']),
            int(request.form['glucose']),
            int(request.form['blood_pressure']),
            int(request.form['skin_thickness']),
            int(request.form['insulin']),
            float(request.form['bmi']),
            float(request.form['diabetes_pedigree_function']),
            int(request.form['age'])
        ]

        # Standardize the input data
        std_data = scaler.transform(np.array(input_data).reshape(1, -1))

        # Make prediction
        prediction = classifier.predict(std_data)

        # Save input data and prediction to the database
        cursor = db.cursor()
        cursor.execute("INSERT INTO user_inputs (pregnancies, glucose, blood_pressure, skin_thickness, insulin, bmi, diabetes_pedigree_function, age, outcome) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       tuple(map(int, input_data + [prediction[0]])))
        db.commit()
        cursor.close()

        result = 'The person is diabetic' if prediction[0] == 1 else 'The person is not diabetic'

        return render_template('result.html', result=result)

    # Redirect to the home page if the request method is not POST
    return redirect('/')

# ...

if __name__ == '__main__':
    app.run(debug=True)
